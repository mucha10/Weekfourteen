alet("Hello my name is Arick!");
documen.write("Hello");
document.write('Who are you?'');
var name=Arick;
alert(name);
